Code tested on the following build of R:

platform       i386-apple-darwin9.8.0       
arch           i386                         
os             darwin9.8.0                  
system         i386, darwin9.8.0            
status                                      
major          2                            
minor          14.2                         
year           2012                         
month          02                           
day            29                           
svn rev        58522                        
language       R                            
version.string R version 2.14.2 (2012-02-29)

Libraries used: ggplot2 and MASS 
ggplot2 can be installed via the command install.packages("ggplot2")
MASS comes bundled with most recent versions of R
both packages need to be loaded via commands require(ggplot2) and require(MASS).

A pdf reader of some kind (available from adobe.com) needed for the viewing of the report